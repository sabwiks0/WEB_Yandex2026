from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_file
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from datetime import datetime
from mutagen.mp3 import MP3
import os

app = Flask(__name__)

HOST = '127.0.0.1'
PORT = 5000

app.config['SECRET_KEY'] = 'your-secret-key-here'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['COVER_FOLDER'] = 'static/covers'

# Создаём папки для загрузки файлов (если их нет)
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['COVER_FOLDER'], exist_ok=True)

db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
# Указываем, куда перенаправлять неавторизованных пользователей
login_manager.login_view = 'login'

# Кодовое слово для администратора (указываем при регистрации)
ADMIN_SECRET = "admin123"


#database вставила сюда, добавила tracks для пользователя
class User(UserMixin, db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), default='user')
    registered_at = db.Column(db.DateTime, default=datetime.now)


class Track(db.Model):
    __tablename__ = 'tracks'
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    artist = db.Column(db.String(200), nullable=False)
    duration = db.Column(db.Integer, default=0)
    file_path = db.Column(db.String(500), nullable=False)
    cover_path = db.Column(db.String(500), nullable=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    uploaded_at = db.Column(db.DateTime, default=datetime.now)
    download_count = db.Column(db.Integer, default=0)


# Загружаем пользователя из БД по ID
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


# Длительность трека в секундах
def get_duration(filepath):
    try:
        audio = MP3(filepath)
        return int(audio.info.length)
    except:
        return 0


# Главная страница (треки отображаются по времени добавления: сначала новые)
@app.route('/')
def index():
    tracks = Track.query.order_by(Track.uploaded_at.desc()).all()
    return render_template('index.html', tracks=tracks)


# Получаем все треки в формате json
@app.route('/api/tracks')
def api_tracks():
    tracks = Track.query.all()
    return jsonify([{
        'id': t.id,
        'title': t.title,
        'artist': t.artist,
        'duration': t.duration,
        'download_count': t.download_count
    } for t in tracks])


@app.route('/register', methods=['GET', 'POST'])
# Страница регистрации
def register():
    if request.method == 'POST':
        # Получаем данные из формы
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        # Кодовое слов (необязательно, нужно для регистрации администратора)
        secret = request.form.get('secret_word', '')

        # Проверка, не занято ли имя пользователя
        if User.query.filter_by(username=username).first():
            flash('Имя пользователя уже существует')
            return redirect(url_for('register'))

        # Проверка, не занята ли почта
        if User.query.filter_by(email=email).first():
            flash('Email уже используется')
            return redirect(url_for('register'))

        # Если кодовое слово совпадает, даем права администратора
        role = 'admin' if secret == ADMIN_SECRET else 'user'
        user = User(username=username, email=email,
                    password=generate_password_hash(password), role=role)
        # Сохраняем в бд
        db.session.add(user)
        db.session.commit()

        flash(f'Регистрация успешна! Вы зарегистрированы как {role}')
        return redirect(url_for('login'))

    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
# Страница входа
def login():
    if request.method == 'POST':
        # Ищем пользователя по имени
        user = User.query.filter_by(username=request.form['username']).first()
        # Если пароль верный, авторизуем пользователя
        if user and check_password_hash(user.password, request.form['password']):
            login_user(user)
            flash(f'Добро пожаловать, {user.username}!')
            return redirect(url_for('index'))
        flash('Неверное имя пользователя или пароль')
    return render_template('login.html')


@app.route('/logout')
@login_required
# Страница выхода из профиля (только для авторизованых пользователей)
def logout():
    logout_user()
    # Сообщение пользователю при выходе из профиля
    flash('👋 Вы успешно вышли из системы', 'info')
    # Перенаправляем на главную страницу
    return redirect(url_for('index'))


# Возможность управления треками (только для администраторов)
@app.route('/upload', methods=['GET', 'POST'])
@login_required
def upload_track():
    # Проверяем, что это администратор
    if current_user.role != 'admin':
        flash('Только администраторы могут загружать треки')
        return redirect(url_for('index'))

    if request.method == 'POST':
        file = request.files['audio_file']
        # Проверяем, что формат файла MP3
        if file and file.filename.endswith('.mp3'):
            filename = secure_filename(f"{datetime.now().timestamp()}_{file.filename}")
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            # Сохраняем трек
            file.save(filepath)

            # Создаем запись о треке в бд
            track = Track(
                title=request.form['title'],
                artist=request.form['artist'],
                duration=get_duration(filepath),
                file_path=filepath,
                user_id=current_user.id
            )
            db.session.add(track)
            db.session.commit()
            flash('Трек успешно загружен!')
            return redirect(url_for('index'))
        else:
            flash('Пожалуйста, загрузите MP3 файл')

    return render_template('upload.html')


# Скачивание трека
@app.route('/download/<int:track_id>')
@login_required
def download_track(track_id):
    # Находим трек или выдаем ошибку
    track = Track.query.get_or_404(track_id)
    # Увеличиваем счетчик скачиваний
    track.download_count += 1
    db.session.commit()
    return send_file(track.file_path, as_attachment=True)


# Можно прослушать трек, не скачивая его на устройство
@app.route('/stream/<int:track_id>')
def stream_track(track_id):
    track = Track.query.get_or_404(track_id)
    return send_file(track.file_path)


# Для удаления трека (могут только администраторв)
@app.route('/delete/<int:track_id>')
@login_required
def delete_track(track_id):
    # Проверяем, что это администратор
    if current_user.role != 'admin':
        flash('Только администраторы могут удалять треки')
        return redirect(url_for('index'))

    track = Track.query.get_or_404(track_id)
    if os.path.exists(track.file_path):
        os.remove(track.file_path)
    db.session.delete(track)
    db.session.commit()
    flash('Трек удален')
    return redirect(url_for('index'))


# Поиск треков по исполнителю или по названию
@app.route('/search')
def search():
    q = request.args.get('q', '').strip()
    if q:
        # Приводим запрос к нижнему регистру
        q_lower = q.lower()
        all_tracks = Track.query.all()
        tracks = []

        for track in all_tracks:
            # Приводим названия и имена артистов к нижнему регистру для сравнения
            if q_lower in track.title.lower() or q_lower in track.artist.lower():
                tracks.append(track)

        if len(tracks) == 0:
            # Если ничего не найдено, выдаем
            flash(f' По запросу "{q}" ничего не найдено. Попробуйте другие ключевые слова.', 'warning')
        else:
            # Если что-то найдено, выдаем
            flash(f'✅ Найдено {len(tracks)} треков по запросу "{q}"', 'success')
        # =========================================

    else:
        tracks = Track.query.all()
        # Если пользователь нажал поиск с пустой строкой
        if request.args.get('q') is not None:
            flash('🔍 Введите текст для поиска', 'info')

    return render_template('index.html', tracks=tracks, search_query=q)


# Запуск
if __name__ == '__main__':
    with app.app_context():
        db.create_all()

        # Если нет ни одного пользователя, создаем "тестового" администратора
        if User.query.count() == 0:
            admin = User(
                username='admin',
                email='admin@example.com',
                password=generate_password_hash('admin123'),
                role='admin'
            )
            db.session.add(admin)
            db.session.commit()
            print("Создан тестовый администратор: admin / admin123")
        else:
            print(f"В базе данных {User.query.count()} пользователей")

    print(f"Адрес: http://{HOST}:{PORT}")
    print(f"Кодовое слово для администратора при регистрации: {ADMIN_SECRET}")
    app.run(host=HOST, port=PORT, debug=True)